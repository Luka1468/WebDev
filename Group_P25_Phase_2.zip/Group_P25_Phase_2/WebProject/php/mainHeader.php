<!-- the design of the navigation bar-->
<!DOCTYPE html>
<html>
<head>
    <title>Blog</title>
    <link rel="stylesheet" type="text/css" href="../css/main.css">

    <meta charset="utf-8">
<body>
<body>

<div class="container">
    <!-- the top of the website where the logo or title/ some navigations can be like top trending, latest news... -->
    <!-- fixed position top left -->
    <div class="header">

        <!-- logo of the blog -->
        <a href="../index.php"><img class="logo" src="https://seeklogo.com/images/R/Russia-logo-BC336FF7A3-seeklogo.com.png"
                                    width="80" height="80"></a>


        <div class="nav">
            <ul id="menu">
                <li><a href="../index.php">Home</a></li>
                <li><a href="">Top 10 Conquests</a>
                    <ul>
                        <li><a href="">Ukraine</a></li>
                        <li><a href="">Yugoslavia</a></li>
                        <li><a href="">USA</a></li>
                    </ul>
                </li>
                <li><a href="">Future Conquests</a>
                    <ul>
                        <li><a href="">Romania</a></li>
                        <li><a href="">France</a></li>
                        <li><a href="">Germany</a></li>

                    </ul>
                </li>
                <li><a href="../AboutMe.php">Contact</a></li>
                <li><a href="../AboutMe.php">About Me</a>

                </li>
            </ul>
        </div>


    </div>
