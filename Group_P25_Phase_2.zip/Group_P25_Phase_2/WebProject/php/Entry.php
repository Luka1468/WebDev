<!--this page is to get a post that you clicked depending on which post you clicked-->
<?php
session_start();

?>

<?php
require 'connect.php';
?>

<?php require 'mainHeader.php'; ?>

<?

require 'fetchClickedPost.php';

require 'sidebar.php'; ?>


    <div class="clear"></div>
    <div class="footer">
    </div>
    </body>
    </html>

<?php
