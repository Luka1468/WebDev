<?php
/**
 * Created by PhpStorm.
 * User: CS
 * Date: 3/28/2019
 * Time: 9:17 AM
 */

$user = "sunjingw_sunj";
$passwd = "CaTep9*4yuJ";
$hostname = "localhost";

?>